
copy of html comparison charts/text and C source code examples from
http://www.cs.utexas.edu/~jpmartin/memCheckers.html
with kind permission of Jean-Philippe Martin.

i've added Makefiles and "#include" lines to the examples
for best DUMA results and to remove compilation errors
occuring when autoincluding the DUMA header files.

Hayati Ayguen

13 January 2008
updated 14 January 2008
