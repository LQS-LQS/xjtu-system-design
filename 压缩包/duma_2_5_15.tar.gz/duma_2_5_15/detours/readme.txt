
Due to EULA restrictions we cannot distribute the Detours source with DUMA.
To build DUMA with detours support download Detours 1.5 and
install to this folder, then build.  You should end up with \lib,
and \include folders here.

http://research.microsoft.com/sn/detours/

See the duma+detours howto in the root folder.

